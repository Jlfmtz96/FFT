<?php
// Definimos todas las palabras en ingles un array
$lang = array(
	"log" => "Iniciar Sesión",
	"change_lang" => "Español (es)",
  "option_en" => "Ingles (en)",
  "option_es" => "Español (es)",
	"h3_slogan" => "No voy detrás del dinero, <br>voy detrás de un sueño: <br><span>Ser Libre!</span>",
	"p_section_file" => "Existe un malentendido de que la gente común y corriente no puede volverse económicamente independiente.
	<br>Personas que tienen un ingreso menor de seis cifras se están volviendo económicamente independientes.",
	"span_section_file" => "¿Cómo lo hicieron?",
	"register_section_file" => "Regístrate y disfruta esta extraordinaria guía financiera <br>",
	"free_section_file" => "totalmente gratis",
	"sign" => "Regístrate",
	"enter_modal" => "Ingresa tus datos",
	"name" => "Nombre:",
	"phone" => "Teléfono:",
	"email" => "Correo Electrónico:",
	"invalid-field" => "*Campo Obligatorio",
	"form_button" => "Enviar",
	"a_video" => "Ver video",
	"modal_footer" => "Por seguridad tus datos no serán compartidos.<br>consulta nuestro",
	"a_footer" => "Aviso de privacidad"
);
