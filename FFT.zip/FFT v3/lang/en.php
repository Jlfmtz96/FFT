<?php
// Definimos todas las palabras en ingles un array
$lang = array(
	"log" => "Login",
	"change_lang" => "English (en)",
  "option_en" => "English (en)",
	"option_es" => "Spanish (es)",
	"h3_slogan" => "I am not after money, <br>I am after a dream: <br><span>Be free!</span>",
	"p_section_file" => "There is a common misunderstanding that average and ordinary folks can’t become financially independent.
	<br>Many people who never earned a six-figure income become financially independent.",
	"span_section_file" => "How do they do it?",
	"register_section_file" => "Register and enjoy this amazing financial guide <br>",
	"free_section_file" => "totally free",
	"sign" => "Sign up",
	"enter_modal" => "Enter your data",
	"name" => "Name:",
	"phone" => "Phone:",
	"email" => "E-mail:",
	"invalid-field" => "*Obligatory field",
	"form_button" => "Send",
	"a_video" => "Watch video",
	"modal_footer" => "For security, your data will not be shared.<br>Check out",
	"a_footer" => "safety notice"
);
