<?php
// iniciamos una sesion
session_start();

//verificamos si hay cambios de lenguaje mediante POST
if(isset($_GET["lang"])){
  $lang = $_GET["lang"];
  if(!empty($lang)){
    $_SESSION["lang"] = $lang;
  }
}
// verificamos la sesion creada
if(isset($_SESSION['lang'])){
  // si es true, se crea el require y la variable lang
  $lang = $_SESSION["lang"];
  require "lang/".$lang.".php";
  // si no hay sesion por default se carga el lenguaje ingles
}else{
  require "lang/en.php";
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/css/fontawesome.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <title></title>
  </head>
  <body>
    <nav id="navegacion-principal" class="navbar fixed-top navbar-light bg-green">
      <div class="container">
        <a href="#" class="navbar-brand text-light">FFT</a>
        <ul class="nav nav-pills">
          <li class="nav-item">
            <form class="form-inline" method="GET">
              <select class="custom-select mb-2 mr-sm-2 mb-sm-0 btn btn-sm" name="lang" onchange="this.form.submit()">
                <option selected hidden><?php echo $lang["change_lang"]; ?></option>
                <option value="en"><?php echo $lang["option_en"]; ?></option>
                <option value="es"><?php echo $lang["option_es"]; ?></option>
              </select>
            </form>

            <li class="nav-item">
              <a href="#" class="nav-link btn btn-outline-light btn-sm btn-font"><?php echo $lang["log"]; ?></a>
            </li>
          </li>
        </ul>
      </div>
    </nav>

    <div class="section-title py-5 mt-5">
      <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6 text-center">
          <h1 class="text-uppercase"><span>F</span>inancial <span>F</span>reedom <span>T</span>eam</h1>
        </div>
      </div>
    </div>

    <div class="section-slide py-5 mt-5">
      <div id="slider-principal" class="container slider-principal carousel slide " data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#slider-principal" data-slide-to="0"></li>
          <li data-target="#slider-principal" data-slide-to="1"></li>
          <li data-target="#slider-principal" data-slide-to="2"></li>
          <li data-target="#slider-principal" data-slide-to="3"></li>
          <li data-target="#slider-principal" data-slide-to="4"></li>
          <li data-target="#slider-principal" data-slide-to="5"></li>
        </ol>
        <div class="carousel-inner" role="listbox">
          <div class="carousel-item active">
            <img src='img/ME-1.svg' class="img-fluid mx-auto">
          </div>
          <div class="carousel-item">
            <img src="img/ME-2.svg" class="img-fluid mx-auto">
          </div>
          <div class="carousel-item">
            <img src="img/ME-3.svg" class="img-fluid mx-auto">
          </div>
          <div class="carousel-item">
            <img src="img/ME-4.svg" class="img-fluid mx-auto">
          </div>
          <div class="carousel-item">
            <img src="img/ME-5.svg" class="img-fluid mx-auto">
          </div>
          <div class="carousel-item">
            <img src="img/ME-6.svg" class="img-fluid mx-auto">
          </div>
        </div><!--carousel-inner-->

      </div><!--slider-->
    </div>

    <section class="section-slogan py-4 mt-5">
      <div class="container text-center">
        <h3 class="text-uppercase"><?php echo $lang["h3_slogan"]; ?></span></h3>
        <p>- Robert Kiyosaki</p>
      </div>
    </section>

    <section class="section-file mt-5">
      <div class="container">
        <div class="row">
          <div class="cover col-md-6 my-4">
            <img src="img/How-Money-Works-US-PPT Caratula.svg" class="img-fluid">
          </div>
          <div class="content-file col-md-6 my-4">
            <p class="m-4 text-justify"><?php echo $lang["p_section_file"]; ?></p>
            <p class="text-center"><span><?php echo $lang["span_section_file"]; ?></span></p>
            <p class="mb-4 text-center"><?php echo $lang["register_section_file"]; ?><span><?php echo $lang["free_section_file"]; ?></span></p>
            <div class="text-center">
              <button type="button" class="btn btn-primary btn-font" data-toggle="modal" data-target="#formModal" data-whatever="@mdo"><?php echo $lang["sign"]; ?></button>
            </div>
          </div>
        </div>
      </div>

      <div class="modal fade" id="formModal" tabindex="-1" role="dialog" aria-labelledby="formModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="formModalLabel"><?php echo $lang["enter_modal"]; ?></h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form class="needs-validation" novalidate>
                <div class="form-group">
                  <label for="name"><?php echo $lang["name"]; ?></label>
                  <input type="text" class="form-control" id="name" required>
                  <div class="invalid-feedback">
                    <?php echo $lang["invalid-field"]; ?>
                  </div>
                </div>
                <div class="form-group">
                  <label for="tel"><?php echo $lang["phone"]; ?></label>
                  <input type="tel" class="form-control" id="tel">
                </div>
                <div class="form-group">
                  <label for="email"><?php echo $lang["email"]; ?></label>
                  <input type="email" class="form-control" id="email" required>
                  <div class="invalid-feedback">
                    <?php echo $lang["invalid-field"]; ?>
                  </div>
                </div>
                <button type="submit" class="btn btn-primary"><?php echo $lang["form_button"]; ?></button>
                <a id="wvideo" class="alert alert-success mt-4 text-center" style="display:none" href="https://freedomforfamilies.com/v/?v=441463753" target="_blank"><?php echo $lang["a_video"]; ?></a>
              </form>
            </div>
            <div class="modal-footer mx-4">
              <p><?php echo $lang["modal_footer"]; ?> <a href="#"><?php echo $lang["a_footer"]; ?></a></p>
            </div>
          </div>
        </div>
      </div>
    </section>


    <footer class="footer-site mt-5">
      <div class="container">
        <div class="row">
          <div class="col-6">
            <h3 class="text-uppercase text-light mt-4">Financial Freedom Team</h3>
          </div>
          <div class="col-6">

          </div>
          <hr class="w-100">
          <p class="text-center copyright w-100">© 2020 Financial Freedom Team</p>
        </div>
      </div>
    </footer>


    <script src="https://kit.fontawesome.com/21af2d7059.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/leaflet@1.6.0/dist/leaflet.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>
