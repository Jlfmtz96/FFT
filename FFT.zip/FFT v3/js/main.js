
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        event.preventDefault();
        if (form.checkValidity() === false) {
          event.stopPropagation();
        } else {
          //Obtener valores del formulario
          var name = document.getElementById('name').value,
              tel = document.getElementById('tel').value,
              email = document.getElementById('email').value;

          //ejecutar Ajax
          var xhr = new XMLHttpRequest();

          //Abrir la conexion
          xhr.open('POST', 'http://localhost/FFT%20v3/inc/contact.php', true);

          //Siempre que utilizas un formulario se debe agregar un header
          xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
          //revisar el estado
          xhr.onload = function(){
            if (xhr.status === 200) {
              var reply = JSON.parse( xhr.responseText );
              console.log(reply);
              if (reply.reply === false) {
                document.getElementById('wvideo').style.display = 'block';
                //setTimeout(function() {
                  //document.querySelector('.alert').remove();
                //}, 3000);
              }
            }
          }

          //Enviar el request
          xhr.send('name='+name+'&tel='+tel+'&email='+email);
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();
