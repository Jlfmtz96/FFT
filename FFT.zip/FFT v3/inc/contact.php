<?php

  $name = $_POST['name'];
  $tel = $_POST['tel'];
  $email = $_POST['email'];
  $header = 'From: ' . $email . "\r\n";
  $header = 'X-Mailer: PHP/' . phpversion() . "\r\n";
  $header = 'Mime-Version: 1.0 \r\n';
  $header = 'Content-Type: text/plain';
  $mensajeCorreo = "This message was sent by: " . $name . "\r\n";
  $mensajeCorreo = "Telefono: " . $tel . "\r\n";
  $mensajeCorreo = "Email: " . $email . "\r\n";
  $for = "jlfmtz96@gmail.com";
  $issue = "Candidate";
  $reply = mail($for, $issue, utf8_encode($mensajeCorreo), $header);

  echo json_encode(array(
    'message' => sprintf('The message has been sent!'),
    'data' => array(
      'name' => $name,
      'tel' => $tel,
      'email' => $email
    ),
    'reply' => $reply
  ));
 ?>
